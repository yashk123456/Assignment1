from scripts.eda import run_eda
from scripts.model import run_model

if __name__ == "__main__":
    print("Starting EDA...")
    run_eda()

    print("Training and Evaluating Model...")
    run_model()

    print("Project Complete.")
