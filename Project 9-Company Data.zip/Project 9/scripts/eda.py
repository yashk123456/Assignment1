import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import os

def run_eda():
    df = pd.read_csv("C:/Users/prath/OneDrive/Desktop/me/Assignments/company_project_9/data/Company_Data.csv")
    print("Data Loaded. Shape:", df.shape)

    os.makedirs("graphs", exist_ok=True)

    sns.histplot(df['Sales'], kde=True)
    plt.title("Sales Distribution")
    plt.savefig("C:/Users/prath/OneDrive/Desktop/me/Assignments/company_project_9/graphs/sales_distribution.png")
    plt.close()

    sns.boxplot(x='Urban', y='Sales', data=df)
    plt.title("Sales by Urban")
    plt.savefig("C:/Users/prath/OneDrive/Desktop/me/Assignments/company_project_9/graphs/sales_by_urban.png")
    plt.close()

    # Additional EDA plots and insights can be added here
    print("EDA Complete. Graphs saved in 'graphs/' folder.")
