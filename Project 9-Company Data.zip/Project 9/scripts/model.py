import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
from sklearn.preprocessing import LabelEncoder

def run_model():
    df = pd.read_csv("C:/Users/prath/OneDrive/Desktop/me/Assignments/company_project_9/data/Company_Data.csv")

    # Convert Sales to High/Low
    median_sales = df['Sales'].median()
    df['High_Sales'] = df['Sales'].apply(lambda x: 1 if x > median_sales else 0)

    # Encode categorical variables
    label_enc = LabelEncoder()
    for col in ['Urban', 'US', 'ShelveLoc']:
        df[col] = label_enc.fit_transform(df[col])

    X = df.drop(columns=['Sales', 'High_Sales'])
    y = df['High_Sales']

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)
    model = RandomForestClassifier(random_state=42)
    model.fit(X_train, y_train)

    predictions = model.predict(X_test)
    print("Model Performance:\n", classification_report(y_test, predictions))
