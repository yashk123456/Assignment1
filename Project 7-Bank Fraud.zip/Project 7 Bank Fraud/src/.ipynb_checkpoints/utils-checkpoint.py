import pandas as pd
import os
import joblib
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, classification_report
from sklearn.preprocessing import StandardScaler


def load_data(path):
    print("\nLoading dataset...")
    df = pd.read_csv(path, sep=';')
    print(f"Dataset shape: {df.shape}")
    return df


def preprocess_data(df):
    print("\nPreprocessing data...")
    df = df.copy()

    # Binary encoding for target variable
    df['y'] = df['y'].map({'yes': 1, 'no': 0})

    # Encode binary columns
    for col in ['default', 'housing', 'loan']:
        df[col] = df[col].map({'yes': 1, 'no': 0})

    # One-hot encoding for categorical columns
    categorical_cols = ['job', 'marital', 'education', 'contact', 'month', 'poutcome']
    df = pd.get_dummies(df, columns=categorical_cols, drop_first=True)

    print("Data preprocessing completed.")
    return df


def remove_highly_correlated_features(df, threshold=0.9):
    corr_matrix = df.corr()
    upper_triangle = corr_matrix.where(
        np.triu(np.ones(corr_matrix.shape), k=1).astype(np.bool)
    )
    to_drop = [column for column in upper_triangle.columns if any(upper_triangle[column] > threshold)]
    print(f"Dropping columns: {to_drop}")
    return df.drop(columns=to_drop)


def split_data(df, target='y', test_size=0.2, random_state=42):
    print("\nSplitting data...")
    X = df.drop(target, axis=1)
    y = df[target]
    
    # Split into training and testing data
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=test_size, random_state=random_state)

    # Feature scaling with StandardScaler
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    return X_train_scaled, X_test_scaled, y_train, y_test


def train_model(X_train, y_train):
    print("\nTraining Decision Tree model...")
    model = DecisionTreeClassifier(random_state=42)
    model.fit(X_train, y_train)
    return model


def evaluate_model(model, X_test, y_test):
    print("\nEvaluating model...")
    y_pred = model.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    print(f"Accuracy: {acc:.4f}\n")
    print("Classification Report:")
    print(classification_report(y_test, y_pred))
    return y_pred


def save_model(model, path="models/decision_tree_model.pkl"):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    joblib.dump(model, path)
    print(f"Model saved to {path}")
