import os
from src.utils import (
    load_data, preprocess_data, split_data,
    train_model, evaluate_model, save_model,
    plot_and_save_roc
)

# Step 1: Load the dataset
data_path = "data/bank-full.csv"
df = load_data(data_path)

# Step 2: Preprocess the dataset
df_clean = preprocess_data(df)

# Step 3: Split the dataset into training and testing sets
X_train, X_test, y_train, y_test = split_data(df_clean)

# Step 4: Train the model
model = train_model(X_train, y_train)

# Step 5: Evaluate the model
y_pred, y_proba = evaluate_model(model, X_test, y_test)

# Step 6: Save the model
save_model(model)

# Step 7: Plot and save the ROC curve
plot_and_save_roc(y_test, y_proba)

print("\nPipeline execution completed successfully.")
